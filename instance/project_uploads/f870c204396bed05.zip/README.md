Bug Detection Demo Project

This small project intentionally contains patterns that a static scanner can detect.
It is safe for demonstration because the scanner should analyze the source code
without executing it.
