import sqlite3
import hashlib

def login(username, password):
    conn = sqlite3.connect("users.db")
    # BUG 1: SQL injection pattern
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    return conn.execute(query).fetchone()

def run_user_code(code):
    # BUG 2: unsafe dynamic execution
    return eval(code)

def make_password(password):
    # BUG 3: weak hashing algorithm
    return hashlib.md5(password.encode()).hexdigest()

def get_app():
    # BUG 4: debug mode enabled
    app = create_app()
    app.debug = True
    return app
