function showMessage(userInput) {
    // BUG 5: unsafe innerHTML assignment
    document.getElementById("message").innerHTML = userInput;
}
