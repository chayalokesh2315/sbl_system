# BUG 6: hardcoded secret
SECRET_KEY = "my-super-secret-password"
