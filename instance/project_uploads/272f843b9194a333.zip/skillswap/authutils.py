from functools import wraps
from flask import session, g, redirect, url_for, request, abort

from models import get_employee, AnonymousEmployee


def load_logged_in_user():
    employee_id = session.get("employee_id")
    if employee_id is None:
        g.user = AnonymousEmployee()
    else:
        user = get_employee(employee_id)
        g.user = user if (user and not user.is_blocked) else AnonymousEmployee()


def get_current_user():
    return getattr(g, "user", AnonymousEmployee())


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not get_current_user().is_authenticated:
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = get_current_user()
        if not user.is_authenticated or not user.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapped
