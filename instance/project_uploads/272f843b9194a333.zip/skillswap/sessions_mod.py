from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import login_required, get_current_user

sessions_bp = Blueprint("sessions", __name__, url_prefix="/exchanges/<int:exchange_id>/sessions")


def _guard(exchange_id, user):
    ex = models.get_exchange(exchange_id)
    if not ex or user.id not in (ex["requester_id"], ex["recipient_id"]):
        return None
    return ex


@sessions_bp.route("/new", methods=["GET", "POST"])
@login_required
def new(exchange_id):
    user = get_current_user()
    ex = _guard(exchange_id, user)
    if not ex:
        flash("Exchange not found.", "error")
        return redirect(url_for("match.exchanges"))
    if ex["status"] != "accepted":
        flash("You can only schedule sessions for an accepted exchange.", "error")
        return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    if request.method == "POST":
        scheduled_at = request.form.get("scheduled_at", "").strip()
        mode = request.form.get("mode", "online")
        location_or_link = request.form.get("location_or_link", "").strip()
        notes = request.form.get("notes", "").strip()
        if not scheduled_at:
            flash("Please pick a date & time.", "error")
        else:
            models.create_session(exchange_id, scheduled_at, mode, location_or_link, notes)
            other_id = ex["recipient_id"] if user.id == ex["requester_id"] else ex["requester_id"]
            models.add_notification(other_id, f"A new session was scheduled for {scheduled_at}.",
                                     link=f"/exchanges/{exchange_id}")
            flash("Session scheduled.", "success")
            return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    return render_template("session_form.html", exchange_id=exchange_id, session=None)


@sessions_bp.route("/<int:session_id>/edit", methods=["GET", "POST"])
@login_required
def edit(exchange_id, session_id):
    user = get_current_user()
    ex = _guard(exchange_id, user)
    if not ex:
        flash("Exchange not found.", "error")
        return redirect(url_for("match.exchanges"))
    sess = models.get_session(session_id)
    if not sess or sess["exchange_id"] != exchange_id:
        flash("Session not found.", "error")
        return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    if request.method == "POST":
        scheduled_at = request.form.get("scheduled_at", "").strip()
        mode = request.form.get("mode", "online")
        location_or_link = request.form.get("location_or_link", "").strip()
        notes = request.form.get("notes", "").strip()
        models.update_session(session_id, scheduled_at=scheduled_at, mode=mode,
                               location_or_link=location_or_link, status="scheduled", notes=notes)
        flash("Session rescheduled.", "success")
        return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    return render_template("session_form.html", exchange_id=exchange_id, session=sess)


@sessions_bp.route("/<int:session_id>/cancel", methods=["POST"])
@login_required
def cancel(exchange_id, session_id):
    user = get_current_user()
    ex = _guard(exchange_id, user)
    if ex:
        models.update_session(session_id, status="cancelled")
        flash("Session cancelled.", "info")
    return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))


@sessions_bp.route("/<int:session_id>/complete", methods=["POST"])
@login_required
def complete(exchange_id, session_id):
    user = get_current_user()
    ex = _guard(exchange_id, user)
    if ex:
        sess = models.get_session(session_id)
        if sess and sess["status"] != "completed":
            models.update_session(session_id, status="completed")
            models.add_points(ex["requester_id"], models.POINTS_PER_SESSION)
            models.add_points(ex["recipient_id"], models.POINTS_PER_SESSION)
            flash("Session marked as completed — points awarded to both participants!", "success")
    return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))
