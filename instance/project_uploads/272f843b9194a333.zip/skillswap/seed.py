"""Seeds initial departments and a starter skill catalog so matching has something to work with."""
import models

DEPARTMENTS = ["Engineering", "Design", "Product", "Marketing", "Sales", "HR", "Finance"]

SKILLS = [
    ("python", "programming"),
    ("javascript", "programming"),
    ("sql", "programming"),
    ("ui/ux design", "design"),
    ("figma", "design"),
    ("public speaking", "soft-skills"),
    ("project management", "management"),
    ("excel", "office"),
    ("data analysis", "analytics"),
    ("machine learning", "programming"),
    ("copywriting", "marketing"),
    ("negotiation", "soft-skills"),
]


def seed_all():
    added_dept = 0
    for name in DEPARTMENTS:
        before = len(models.list_departments())
        models.create_department(name)
        after = len(models.list_departments())
        added_dept += (after - before)

    added_skills = 0
    for name, category in SKILLS:
        if models.get_skill_by_name(name):
            continue
        models.create_skill(name, category)
        added_skills += 1

    print(f"Seeded {added_dept} new department(s), {added_skills} new skill(s).")
