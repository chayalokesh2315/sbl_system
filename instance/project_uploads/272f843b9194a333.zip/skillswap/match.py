from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import login_required, get_current_user

match_bp = Blueprint("match", __name__)


@match_bp.route("/matches")
@login_required
def matches():
    user = get_current_user()
    results = models.find_matches(user.id)
    my_offered = models.get_employee_skills(user.id, kind="offer")
    return render_template("matches.html", results=results, my_offered=my_offered)


@match_bp.route("/exchange/request/<int:recipient_id>", methods=["GET", "POST"])
@login_required
def request_exchange(recipient_id):
    user = get_current_user()
    recipient = models.get_employee(recipient_id)
    if not recipient:
        flash("Employee not found.", "error")
        return redirect(url_for("match.matches"))

    my_offered = models.get_employee_skills(user.id, kind="offer")
    their_offered = models.get_employee_skills(recipient_id, kind="offer")

    if request.method == "POST":
        teach_skill_id = request.form.get("teach_skill_id")
        learn_skill_id = request.form.get("learn_skill_id")
        message = request.form.get("message", "").strip()

        if not teach_skill_id or not learn_skill_id:
            flash("Please choose a skill to teach and a skill to learn.", "error")
        else:
            exchange_id = models.create_exchange_request(
                user.id, recipient_id, teach_skill_id, learn_skill_id, message
            )
            models.add_notification(
                recipient_id,
                f"{user.full_name} sent you a SkillSwap request.",
                link=f"/exchanges/{exchange_id}",
            )
            flash("Exchange request sent!", "success")
            return redirect(url_for("match.exchanges"))

    return render_template("request_exchange.html", recipient=recipient,
                            my_offered=my_offered, their_offered=their_offered)


@match_bp.route("/exchanges")
@login_required
def exchanges():
    user = get_current_user()
    status_filter = request.args.get("status")
    incoming = models.list_exchanges_for(user.id, status=status_filter, role="recipient")
    outgoing = models.list_exchanges_for(user.id, status=status_filter, role="requester")

    def enrich(rows):
        out = []
        for r in rows:
            r = dict(r)
            r["requester"] = models.get_employee(r["requester_id"])
            r["recipient"] = models.get_employee(r["recipient_id"])
            r["teach_skill"] = models.get_skill(r["teach_skill_id"])
            r["learn_skill"] = models.get_skill(r["learn_skill_id"])
            out.append(r)
        return out

    return render_template("exchanges.html", incoming=enrich(incoming), outgoing=enrich(outgoing))


@match_bp.route("/exchanges/<int:exchange_id>")
@login_required
def exchange_detail(exchange_id):
    user = get_current_user()
    ex = models.get_exchange(exchange_id)
    if not ex or user.id not in (ex["requester_id"], ex["recipient_id"]):
        flash("Exchange not found.", "error")
        return redirect(url_for("match.exchanges"))

    ex["requester"] = models.get_employee(ex["requester_id"])
    ex["recipient"] = models.get_employee(ex["recipient_id"])
    ex["teach_skill"] = models.get_skill(ex["teach_skill_id"])
    ex["learn_skill"] = models.get_skill(ex["learn_skill_id"])
    sessions = models.list_sessions_for_exchange(exchange_id)
    other_id = ex["recipient_id"] if user.id == ex["requester_id"] else ex["requester_id"]
    resources = models.list_resources(exchange_id=exchange_id)
    already_rated = models.has_rated(exchange_id, user.id)
    return render_template("exchange_detail.html", ex=ex, sessions=sessions,
                            other_id=other_id, resources=resources, already_rated=already_rated)


@match_bp.route("/exchanges/<int:exchange_id>/respond", methods=["POST"])
@login_required
def respond(exchange_id):
    user = get_current_user()
    ex = models.get_exchange(exchange_id)
    if not ex or ex["recipient_id"] != user.id:
        flash("You can't respond to this request.", "error")
        return redirect(url_for("match.exchanges"))

    decision = request.form.get("decision")
    if decision == "accept":
        models.update_exchange_status(exchange_id, "accepted")
        models.add_notification(ex["requester_id"], f"{user.full_name} accepted your SkillSwap request.",
                                 link=f"/exchanges/{exchange_id}")
        flash("Exchange accepted — you can now schedule sessions.", "success")
    elif decision == "reject":
        models.update_exchange_status(exchange_id, "rejected")
        models.add_notification(ex["requester_id"], f"{user.full_name} declined your SkillSwap request.",
                                 link=f"/exchanges/{exchange_id}")
        flash("Exchange declined.", "info")
    return redirect(url_for("match.exchanges"))


@match_bp.route("/exchanges/<int:exchange_id>/complete", methods=["POST"])
@login_required
def complete(exchange_id):
    user = get_current_user()
    ex = models.get_exchange(exchange_id)
    if not ex or user.id not in (ex["requester_id"], ex["recipient_id"]):
        flash("Exchange not found.", "error")
        return redirect(url_for("match.exchanges"))
    models.update_exchange_status(exchange_id, "completed")
    other_id = ex["recipient_id"] if user.id == ex["requester_id"] else ex["requester_id"]
    models.add_notification(other_id, f"{user.full_name} marked your SkillSwap as completed.",
                             link=f"/exchanges/{exchange_id}")
    flash("Exchange marked as completed. Don't forget to leave a rating!", "success")
    return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))
