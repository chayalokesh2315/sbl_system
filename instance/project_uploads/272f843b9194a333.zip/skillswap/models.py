from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db, now

BADGE_THRESHOLDS = [
    (1, "First Swap", "Completed your first session"),
    (5, "Regular Contributor", "Completed 5 sessions"),
    (15, "Skill Champion", "Completed 15 sessions"),
    (30, "SkillSwap Legend", "Completed 30 sessions"),
]
POINTS_PER_SESSION = 10
POINTS_PER_RATING_RECEIVED = 2


class Employee:
    def __init__(self, row):
        self._row = row

    def __getattr__(self, item):
        return self._row[item]

    @property
    def is_authenticated(self):
        return True

    @property
    def is_admin(self):
        return self._row["role"] == "admin"


class AnonymousEmployee:
    is_authenticated = False
    is_admin = False
    username = None
    id = None


# ---------- Departments ----------

def list_departments():
    conn = get_db()
    rows = conn.execute("SELECT * FROM departments ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_department(name):
    conn = get_db()
    try:
        conn.execute("INSERT INTO departments (name) VALUES (?)", (name,))
        conn.commit()
    except Exception:
        pass
    conn.close()


def delete_department(dept_id):
    conn = get_db()
    conn.execute("DELETE FROM departments WHERE id = ?", (dept_id,))
    conn.commit()
    conn.close()


# ---------- Employees ----------

def create_employee(username, email, password, full_name, department_id=None,
                     designation=None, experience_level="beginner", role="employee"):
    conn = get_db()
    conn.execute(
        """INSERT INTO employees
           (username, email, password_hash, full_name, department_id, designation,
            experience_level, points, role, is_blocked, created_at)
           VALUES (?,?,?,?,?,?,?,0,?,0,?)""",
        (username, email, generate_password_hash(password), full_name, department_id,
         designation, experience_level, role, now()),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM employees WHERE username = ?", (username,)).fetchone()
    conn.close()
    return Employee(row)


def get_employee(employee_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM employees WHERE id = ?", (employee_id,)).fetchone()
    conn.close()
    return Employee(row) if row else None


def get_employee_by_identifier(identifier):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM employees WHERE username = ? OR email = ?", (identifier, identifier)
    ).fetchone()
    conn.close()
    return Employee(row) if row else None


def employee_exists(username, email):
    conn = get_db()
    row = conn.execute(
        "SELECT id FROM employees WHERE username = ? OR email = ?", (username, email)
    ).fetchone()
    conn.close()
    return row is not None


def check_password(employee, raw_password):
    return check_password_hash(employee._row["password_hash"], raw_password)


def set_password(employee_id, new_password):
    conn = get_db()
    conn.execute("UPDATE employees SET password_hash = ? WHERE id = ?",
                 (generate_password_hash(new_password), employee_id))
    conn.commit()
    conn.close()


def update_profile(employee_id, full_name, department_id, designation, experience_level, bio):
    conn = get_db()
    conn.execute(
        """UPDATE employees SET full_name=?, department_id=?, designation=?,
           experience_level=?, bio=? WHERE id=?""",
        (full_name, department_id, designation, experience_level, bio, employee_id),
    )
    conn.commit()
    conn.close()


def list_employees(exclude_id=None, blocked_only=False):
    conn = get_db()
    sql = "SELECT * FROM employees WHERE 1=1"
    params = []
    if exclude_id:
        sql += " AND id != ?"
        params.append(exclude_id)
    if blocked_only:
        sql += " AND is_blocked = 1"
    sql += " ORDER BY created_at DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [Employee(r) for r in rows]


def toggle_block(employee_id):
    conn = get_db()
    row = conn.execute("SELECT is_blocked FROM employees WHERE id = ?", (employee_id,)).fetchone()
    new_val = 0 if row["is_blocked"] else 1
    conn.execute("UPDATE employees SET is_blocked = ? WHERE id = ?", (new_val, employee_id))
    conn.commit()
    conn.close()
    return new_val


def toggle_role(employee_id):
    conn = get_db()
    row = conn.execute("SELECT role FROM employees WHERE id = ?", (employee_id,)).fetchone()
    new_role = "employee" if row["role"] == "admin" else "admin"
    conn.execute("UPDATE employees SET role = ? WHERE id = ?", (new_role, employee_id))
    conn.commit()
    conn.close()
    return new_role


def add_points(employee_id, amount):
    conn = get_db()
    conn.execute("UPDATE employees SET points = points + ? WHERE id = ?", (amount, employee_id))
    conn.commit()
    conn.close()


def department_name(department_id):
    if not department_id:
        return None
    conn = get_db()
    row = conn.execute("SELECT name FROM departments WHERE id = ?", (department_id,)).fetchone()
    conn.close()
    return row["name"] if row else None


# ---------- Skills ----------

def create_skill(name, category):
    conn = get_db()
    try:
        conn.execute("INSERT INTO skills (name, category, created_at) VALUES (?,?,?)",
                     (name, category, now()))
        conn.commit()
    except Exception:
        pass
    row = conn.execute("SELECT * FROM skills WHERE name = ?", (name,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_skill_by_name(name):
    conn = get_db()
    row = conn.execute("SELECT * FROM skills WHERE name = ?", (name,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_skill(skill_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM skills WHERE id = ?", (skill_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_skills(query=None, category=None):
    conn = get_db()
    sql = "SELECT * FROM skills WHERE 1=1"
    params = []
    if query:
        sql += " AND name LIKE ?"
        params.append(f"%{query}%")
    if category:
        sql += " AND category = ?"
        params.append(category)
    sql += " ORDER BY category, name"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_skill_categories():
    conn = get_db()
    rows = conn.execute("SELECT DISTINCT category FROM skills ORDER BY category").fetchall()
    conn.close()
    return [r["category"] for r in rows]


def update_skill(skill_id, name, category):
    conn = get_db()
    conn.execute("UPDATE skills SET name=?, category=? WHERE id=?", (name, category, skill_id))
    conn.commit()
    conn.close()


def delete_skill(skill_id):
    conn = get_db()
    conn.execute("DELETE FROM skills WHERE id = ?", (skill_id,))
    conn.commit()
    conn.close()


# ---------- Employee <-> Skills ----------

def add_employee_skill(employee_id, skill_id, kind, level="beginner"):
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO employee_skills (employee_id, skill_id, kind, level, created_at) VALUES (?,?,?,?,?)",
            (employee_id, skill_id, kind, level, now()),
        )
        conn.commit()
    except Exception:
        conn.execute(
            "UPDATE employee_skills SET level = ? WHERE employee_id=? AND skill_id=? AND kind=?",
            (level, employee_id, skill_id, kind),
        )
        conn.commit()
    conn.close()


def remove_employee_skill(entry_id, employee_id):
    conn = get_db()
    conn.execute("DELETE FROM employee_skills WHERE id = ? AND employee_id = ?", (entry_id, employee_id))
    conn.commit()
    conn.close()


def get_employee_skills(employee_id, kind=None):
    conn = get_db()
    sql = """SELECT employee_skills.*, skills.name as skill_name, skills.category as skill_category
             FROM employee_skills JOIN skills ON skills.id = employee_skills.skill_id
             WHERE employee_id = ?"""
    params = [employee_id]
    if kind:
        sql += " AND kind = ?"
        params.append(kind)
    sql += " ORDER BY skills.name"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------- Matching ----------

def find_matches(employee_id):
    """
    For a given employee, find other employees whose OFFERED skills overlap
    with what this employee WANTS, and vice versa. Returns a sorted list of
    candidate dicts with a compatibility score.
    """
    conn = get_db()
    my_wants = {r["skill_id"] for r in conn.execute(
        "SELECT skill_id FROM employee_skills WHERE employee_id=? AND kind='want'", (employee_id,))}
    my_offers = {r["skill_id"] for r in conn.execute(
        "SELECT skill_id FROM employee_skills WHERE employee_id=? AND kind='offer'", (employee_id,))}

    candidates = {}
    if my_wants:
        q_marks = ",".join("?" * len(my_wants))
        rows = conn.execute(
            f"""SELECT employee_id, skill_id FROM employee_skills
                WHERE kind='offer' AND employee_id != ? AND skill_id IN ({q_marks})""",
            [employee_id, *my_wants],
        ).fetchall()
        for r in rows:
            c = candidates.setdefault(r["employee_id"], {"can_learn": [], "can_teach": [], "score": 0})
            c["can_learn"].append(r["skill_id"])
            c["score"] += 1

    if my_offers:
        q_marks = ",".join("?" * len(my_offers))
        rows = conn.execute(
            f"""SELECT employee_id, skill_id FROM employee_skills
                WHERE kind='want' AND employee_id != ? AND skill_id IN ({q_marks})""",
            [employee_id, *my_offers],
        ).fetchall()
        for r in rows:
            c = candidates.setdefault(r["employee_id"], {"can_learn": [], "can_teach": [], "score": 0})
            c["can_teach"].append(r["skill_id"])
            c["score"] += 1

    results = []
    for emp_id, info in candidates.items():
        emp_row = conn.execute("SELECT * FROM employees WHERE id = ? AND is_blocked = 0", (emp_id,)).fetchone()
        if not emp_row:
            continue
        skill_names = {}
        all_ids = set(info["can_learn"]) | set(info["can_teach"])
        if all_ids:
            q_marks = ",".join("?" * len(all_ids))
            for s in conn.execute(f"SELECT id, name FROM skills WHERE id IN ({q_marks})", list(all_ids)):
                skill_names[s["id"]] = s["name"]
        results.append({
            "employee": Employee(emp_row),
            "score": info["score"],
            "mutual": bool(info["can_learn"]) and bool(info["can_teach"]),
            "can_learn_from_them": [skill_names[i] for i in info["can_learn"]],
            "can_teach_them": [skill_names[i] for i in info["can_teach"]],
        })
    conn.close()
    results.sort(key=lambda r: (r["mutual"], r["score"]), reverse=True)
    return results


# ---------- Exchange requests ----------

def create_exchange_request(requester_id, recipient_id, teach_skill_id, learn_skill_id, message):
    conn = get_db()
    ts = now()
    conn.execute(
        """INSERT INTO exchange_requests
           (requester_id, recipient_id, teach_skill_id, learn_skill_id, message, status, created_at, updated_at)
           VALUES (?,?,?,?,?, 'pending', ?, ?)""",
        (requester_id, recipient_id, teach_skill_id, learn_skill_id, message, ts, ts),
    )
    conn.commit()
    new_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    conn.close()
    return new_id


def get_exchange(exchange_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM exchange_requests WHERE id = ?", (exchange_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_exchanges_for(employee_id, status=None, role=None):
    """role: 'requester' | 'recipient' | None (either)"""
    conn = get_db()
    sql = "SELECT * FROM exchange_requests WHERE "
    if role == "requester":
        sql += "requester_id = ?"
        params = [employee_id]
    elif role == "recipient":
        sql += "recipient_id = ?"
        params = [employee_id]
    else:
        sql += "(requester_id = ? OR recipient_id = ?)"
        params = [employee_id, employee_id]
    if status:
        sql += " AND status = ?"
        params.append(status)
    sql += " ORDER BY updated_at DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_exchange_status(exchange_id, status):
    conn = get_db()
    conn.execute("UPDATE exchange_requests SET status=?, updated_at=? WHERE id=?",
                 (status, now(), exchange_id))
    conn.commit()
    conn.close()


def count_active_exchanges():
    conn = get_db()
    n = conn.execute("SELECT COUNT(*) AS n FROM exchange_requests WHERE status='accepted'").fetchone()["n"]
    conn.close()
    return n


def count_all_exchanges():
    conn = get_db()
    n = conn.execute("SELECT COUNT(*) AS n FROM exchange_requests").fetchone()["n"]
    conn.close()
    return n


# ---------- Sessions ----------

def create_session(exchange_id, scheduled_at, mode, location_or_link, notes):
    conn = get_db()
    conn.execute(
        """INSERT INTO sessions (exchange_id, scheduled_at, mode, location_or_link, status, notes, created_at)
           VALUES (?,?,?,?, 'scheduled', ?, ?)""",
        (exchange_id, scheduled_at, mode, location_or_link, notes, now()),
    )
    conn.commit()
    conn.close()


def get_session(session_id):
    conn = get_db()
    row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_sessions_for_exchange(exchange_id):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM sessions WHERE exchange_id = ? ORDER BY scheduled_at", (exchange_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_upcoming_sessions_for(employee_id):
    conn = get_db()
    rows = conn.execute(
        """SELECT sessions.*, exchange_requests.requester_id, exchange_requests.recipient_id
           FROM sessions JOIN exchange_requests ON exchange_requests.id = sessions.exchange_id
           WHERE (exchange_requests.requester_id = ? OR exchange_requests.recipient_id = ?)
             AND sessions.status = 'scheduled'
           ORDER BY sessions.scheduled_at""",
        (employee_id, employee_id),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_session(session_id, scheduled_at=None, mode=None, location_or_link=None, status=None, notes=None):
    conn = get_db()
    row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
    if not row:
        conn.close()
        return
    conn.execute(
        """UPDATE sessions SET scheduled_at=?, mode=?, location_or_link=?, status=?, notes=? WHERE id=?""",
        (scheduled_at or row["scheduled_at"], mode or row["mode"],
         location_or_link if location_or_link is not None else row["location_or_link"],
         status or row["status"], notes if notes is not None else row["notes"], session_id),
    )
    conn.commit()
    conn.close()


def count_completed_sessions(employee_id=None):
    conn = get_db()
    if employee_id:
        n = conn.execute(
            """SELECT COUNT(*) AS n FROM sessions
               JOIN exchange_requests ON exchange_requests.id = sessions.exchange_id
               WHERE sessions.status='completed'
                 AND (exchange_requests.requester_id=? OR exchange_requests.recipient_id=?)""",
            (employee_id, employee_id),
        ).fetchone()["n"]
    else:
        n = conn.execute("SELECT COUNT(*) AS n FROM sessions WHERE status='completed'").fetchone()["n"]
    conn.close()
    return n


# ---------- Ratings ----------

def add_rating(exchange_id, rater_id, ratee_id, score, comment):
    conn = get_db()
    try:
        conn.execute(
            """INSERT INTO ratings (exchange_id, rater_id, ratee_id, score, comment, created_at)
               VALUES (?,?,?,?,?,?)""",
            (exchange_id, rater_id, ratee_id, score, comment, now()),
        )
        conn.commit()
        ok = True
    except Exception:
        ok = False
    conn.close()
    if ok:
        add_points(ratee_id, POINTS_PER_RATING_RECEIVED)
    return ok


def get_ratings_for(employee_id):
    conn = get_db()
    rows = conn.execute(
        """SELECT ratings.*, employees.username AS rater_username
           FROM ratings JOIN employees ON employees.id = ratings.rater_id
           WHERE ratee_id = ? ORDER BY ratings.created_at DESC""",
        (employee_id,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def average_rating(employee_id):
    conn = get_db()
    row = conn.execute("SELECT AVG(score) AS avg FROM ratings WHERE ratee_id = ?", (employee_id,)).fetchone()
    conn.close()
    return round(row["avg"], 1) if row["avg"] else None


def has_rated(exchange_id, rater_id):
    conn = get_db()
    row = conn.execute(
        "SELECT id FROM ratings WHERE exchange_id=? AND rater_id=?", (exchange_id, rater_id)
    ).fetchone()
    conn.close()
    return row is not None


# ---------- Resources ----------

def add_resource(uploaded_by, title, description, url, skill_id=None, exchange_id=None):
    conn = get_db()
    conn.execute(
        """INSERT INTO resources (skill_id, exchange_id, uploaded_by, title, description, url, created_at)
           VALUES (?,?,?,?,?,?,?)""",
        (skill_id, exchange_id, uploaded_by, title, description, url, now()),
    )
    conn.commit()
    conn.close()


def list_resources(skill_id=None, exchange_id=None):
    conn = get_db()
    sql = """SELECT resources.*, employees.username AS uploader
             FROM resources JOIN employees ON employees.id = resources.uploaded_by WHERE 1=1"""
    params = []
    if skill_id:
        sql += " AND skill_id = ?"
        params.append(skill_id)
    if exchange_id:
        sql += " AND exchange_id = ?"
        params.append(exchange_id)
    sql += " ORDER BY resources.created_at DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_resource(resource_id):
    conn = get_db()
    conn.execute("DELETE FROM resources WHERE id = ?", (resource_id,))
    conn.commit()
    conn.close()


# ---------- Notifications ----------

def add_notification(employee_id, message, link=None):
    conn = get_db()
    conn.execute(
        "INSERT INTO notifications (employee_id, message, link, is_read, created_at) VALUES (?,?,?,0,?)",
        (employee_id, message, link, now()),
    )
    conn.commit()
    conn.close()


def list_notifications(employee_id, unread_only=False, limit=None):
    conn = get_db()
    sql = "SELECT * FROM notifications WHERE employee_id = ?"
    params = [employee_id]
    if unread_only:
        sql += " AND is_read = 0"
    sql += " ORDER BY created_at DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_unread_notifications(employee_id):
    conn = get_db()
    n = conn.execute(
        "SELECT COUNT(*) AS n FROM notifications WHERE employee_id=? AND is_read=0", (employee_id,)
    ).fetchone()["n"]
    conn.close()
    return n


def mark_notifications_read(employee_id):
    conn = get_db()
    conn.execute("UPDATE notifications SET is_read = 1 WHERE employee_id = ?", (employee_id,))
    conn.commit()
    conn.close()


# ---------- Gamification ----------

def badges_for(employee_id):
    completed = count_completed_sessions(employee_id)
    earned = [b for b in BADGE_THRESHOLDS if completed >= b[0]]
    next_badge = next((b for b in BADGE_THRESHOLDS if completed < b[0]), None)
    return {"completed_sessions": completed, "earned": earned, "next": next_badge}


def leaderboard(limit=10):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM employees WHERE is_blocked=0 ORDER BY points DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [Employee(r) for r in rows]


# ---------- Analytics (admin) ----------

def most_popular_skills(limit=5):
    conn = get_db()
    rows = conn.execute(
        """SELECT skills.name, COUNT(*) AS n FROM employee_skills
           JOIN skills ON skills.id = employee_skills.skill_id
           GROUP BY skills.id ORDER BY n DESC LIMIT ?""", (limit,)
    ).fetchall()
    conn.close()
    return [(r["name"], r["n"]) for r in rows]


def most_active_employees(limit=5):
    conn = get_db()
    rows = conn.execute(
        """SELECT employees.username, COUNT(*) AS n FROM sessions
           JOIN exchange_requests ON exchange_requests.id = sessions.exchange_id
           JOIN employees ON employees.id = exchange_requests.requester_id
           WHERE sessions.status='completed'
           GROUP BY employees.id ORDER BY n DESC LIMIT ?""", (limit,)
    ).fetchall()
    conn.close()
    return [(r["username"], r["n"]) for r in rows]


def department_participation():
    conn = get_db()
    rows = conn.execute(
        """SELECT departments.name, COUNT(DISTINCT employees.id) AS n
           FROM employees LEFT JOIN departments ON departments.id = employees.department_id
           GROUP BY departments.id ORDER BY n DESC"""
    ).fetchall()
    conn.close()
    return [(r["name"] or "Unassigned", r["n"]) for r in rows]


def count_employees():
    conn = get_db()
    n = conn.execute("SELECT COUNT(*) AS n FROM employees").fetchone()["n"]
    conn.close()
    return n


def count_skills():
    conn = get_db()
    n = conn.execute("SELECT COUNT(*) AS n FROM skills").fetchone()["n"]
    conn.close()
    return n
