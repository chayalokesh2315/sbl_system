import os
from datetime import datetime
from flask import Flask

from db import init_db
from authutils import load_logged_in_user, get_current_user
import models


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    with app.app_context():
        init_db()
        from seed import seed_all
        seed_all()

    app.before_request(load_logged_in_user)

    @app.context_processor
    def inject_globals():
        user = get_current_user()
        unread = models.count_unread_notifications(user.id) if user.is_authenticated else 0
        return {"current_user": user, "unread_notifications": unread}

    @app.template_filter("fmtdate")
    def fmtdate(value, fmt="%d %b %Y, %H:%M"):
        if not value:
            return "—"
        try:
            return datetime.fromisoformat(value).strftime(fmt)
        except (TypeError, ValueError):
            return value

    from auth import auth_bp
    from main import main_bp
    from employee import employee_bp
    from match import match_bp
    from sessions_mod import sessions_bp
    from ratings_mod import ratings_bp
    from resources_mod import resources_bp
    from notifications_mod import notifications_bp
    from admin import admin_bp

    for bp in (auth_bp, main_bp, employee_bp, match_bp, sessions_bp,
               ratings_bp, resources_bp, notifications_bp, admin_bp):
        app.register_blueprint(bp)

    @app.errorhandler(403)
    def forbidden(e):
        return "403 Forbidden: admin access required.", 403

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5001)
