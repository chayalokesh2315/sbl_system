import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "skillswap.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    department_id INTEGER,
    designation TEXT,
    experience_level TEXT DEFAULT 'beginner',
    bio TEXT,
    points INTEGER NOT NULL DEFAULT 0,
    role TEXT NOT NULL DEFAULT 'employee',
    is_blocked INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);

CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS employee_skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    skill_id INTEGER NOT NULL,
    kind TEXT NOT NULL,               -- 'offer' | 'want'
    level TEXT NOT NULL DEFAULT 'beginner',
    created_at TEXT NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees (id),
    FOREIGN KEY (skill_id) REFERENCES skills (id),
    UNIQUE(employee_id, skill_id, kind)
);

CREATE TABLE IF NOT EXISTS exchange_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    requester_id INTEGER NOT NULL,
    recipient_id INTEGER NOT NULL,
    teach_skill_id INTEGER NOT NULL,   -- skill the REQUESTER will teach
    learn_skill_id INTEGER NOT NULL,   -- skill the REQUESTER wants to learn (recipient's offered skill)
    message TEXT,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending|accepted|rejected|completed|cancelled
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (requester_id) REFERENCES employees (id),
    FOREIGN KEY (recipient_id) REFERENCES employees (id),
    FOREIGN KEY (teach_skill_id) REFERENCES skills (id),
    FOREIGN KEY (learn_skill_id) REFERENCES skills (id)
);

CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exchange_id INTEGER NOT NULL,
    scheduled_at TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'online',   -- online|offline
    location_or_link TEXT,
    status TEXT NOT NULL DEFAULT 'scheduled', -- scheduled|completed|cancelled
    notes TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (exchange_id) REFERENCES exchange_requests (id)
);

CREATE TABLE IF NOT EXISTS ratings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exchange_id INTEGER NOT NULL,
    rater_id INTEGER NOT NULL,
    ratee_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    comment TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (exchange_id) REFERENCES exchange_requests (id),
    FOREIGN KEY (rater_id) REFERENCES employees (id),
    FOREIGN KEY (ratee_id) REFERENCES employees (id),
    UNIQUE(exchange_id, rater_id)
);

CREATE TABLE IF NOT EXISTS resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_id INTEGER,
    exchange_id INTEGER,
    uploaded_by INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    url TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (uploaded_by) REFERENCES employees (id)
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    link TEXT,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees (id)
);
"""


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def now():
    return datetime.utcnow().isoformat(timespec="seconds")
