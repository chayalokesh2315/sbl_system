from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import admin_required, get_current_user

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/")
@admin_required
def dashboard():
    return render_template(
        "admin/dashboard.html",
        total_employees=models.count_employees(),
        total_skills=models.count_skills(),
        active_exchanges=models.count_active_exchanges(),
        total_exchanges=models.count_all_exchanges(),
        popular_skills=models.most_popular_skills(5),
        active_employees=models.most_active_employees(5),
        dept_participation=models.department_participation(),
    )


@admin_bp.route("/employees")
@admin_required
def employees():
    return render_template("admin/employees.html", employees=models.list_employees())


@admin_bp.route("/employees/<int:employee_id>/toggle-block", methods=["POST"])
@admin_required
def toggle_block(employee_id):
    current = get_current_user()
    if employee_id == current.id:
        flash("You can't block your own account.", "error")
    else:
        new_val = models.toggle_block(employee_id)
        flash("Employee blocked." if new_val else "Employee unblocked.", "success")
    return redirect(url_for("admin.employees"))


@admin_bp.route("/employees/<int:employee_id>/toggle-role", methods=["POST"])
@admin_required
def toggle_role(employee_id):
    current = get_current_user()
    if employee_id == current.id:
        flash("You can't change your own role.", "error")
    else:
        new_role = models.toggle_role(employee_id)
        flash(f"Employee is now {new_role}.", "success")
    return redirect(url_for("admin.employees"))


@admin_bp.route("/skills")
@admin_required
def skills():
    return render_template("admin/skills.html", skills=models.list_skills())


@admin_bp.route("/skills/new", methods=["GET", "POST"])
@admin_required
def skill_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip().lower()
        category = request.form.get("category", "general").strip().lower()
        if not name:
            flash("Skill name is required.", "error")
        elif models.get_skill_by_name(name):
            flash("That skill already exists.", "error")
        else:
            models.create_skill(name, category)
            flash(f'Skill "{name}" added.', "success")
            return redirect(url_for("admin.skills"))
    return render_template("admin/skill_form.html", skill=None)


@admin_bp.route("/skills/<int:skill_id>/edit", methods=["GET", "POST"])
@admin_required
def skill_edit(skill_id):
    skill = models.get_skill(skill_id)
    if not skill:
        flash("Skill not found.", "error")
        return redirect(url_for("admin.skills"))
    if request.method == "POST":
        name = request.form.get("name", skill["name"]).strip().lower()
        category = request.form.get("category", skill["category"]).strip().lower()
        models.update_skill(skill_id, name, category)
        flash("Skill updated.", "success")
        return redirect(url_for("admin.skills"))
    return render_template("admin/skill_form.html", skill=skill)


@admin_bp.route("/skills/<int:skill_id>/delete", methods=["POST"])
@admin_required
def skill_delete(skill_id):
    models.delete_skill(skill_id)
    flash("Skill deleted.", "info")
    return redirect(url_for("admin.skills"))


@admin_bp.route("/departments")
@admin_required
def departments():
    return render_template("admin/departments.html", departments=models.list_departments())


@admin_bp.route("/departments/new", methods=["POST"])
@admin_required
def department_new():
    name = request.form.get("name", "").strip()
    if name:
        models.create_department(name)
        flash(f'Department "{name}" added.', "success")
    return redirect(url_for("admin.departments"))


@admin_bp.route("/departments/<int:dept_id>/delete", methods=["POST"])
@admin_required
def department_delete(dept_id):
    models.delete_department(dept_id)
    flash("Department removed.", "info")
    return redirect(url_for("admin.departments"))


@admin_bp.route("/exchanges")
@admin_required
def exchanges():
    conn_rows = []
    for status in ("pending", "accepted", "completed", "rejected", "cancelled"):
        pass
    from db import get_db
    conn = get_db()
    rows = conn.execute("SELECT * FROM exchange_requests ORDER BY updated_at DESC").fetchall()
    conn.close()
    enriched = []
    for r in rows:
        r = dict(r)
        r["requester"] = models.get_employee(r["requester_id"])
        r["recipient"] = models.get_employee(r["recipient_id"])
        r["teach_skill"] = models.get_skill(r["teach_skill_id"])
        r["learn_skill"] = models.get_skill(r["learn_skill_id"])
        enriched.append(r)
    return render_template("admin/exchanges.html", exchanges=enriched)
