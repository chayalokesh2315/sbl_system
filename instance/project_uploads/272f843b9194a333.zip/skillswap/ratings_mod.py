from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import login_required, get_current_user

ratings_bp = Blueprint("ratings", __name__, url_prefix="/exchanges/<int:exchange_id>/rate")


@ratings_bp.route("", methods=["GET", "POST"])
@login_required
def rate(exchange_id):
    user = get_current_user()
    ex = models.get_exchange(exchange_id)
    if not ex or user.id not in (ex["requester_id"], ex["recipient_id"]):
        flash("Exchange not found.", "error")
        return redirect(url_for("match.exchanges"))
    if ex["status"] != "completed":
        flash("You can only rate a completed exchange.", "error")
        return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))
    if models.has_rated(exchange_id, user.id):
        flash("You've already rated this exchange.", "info")
        return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    ratee_id = ex["recipient_id"] if user.id == ex["requester_id"] else ex["requester_id"]
    ratee = models.get_employee(ratee_id)

    if request.method == "POST":
        score = int(request.form.get("score", 0))
        comment = request.form.get("comment", "").strip()
        if score < 1 or score > 5:
            flash("Please choose a score between 1 and 5.", "error")
        else:
            models.add_rating(exchange_id, user.id, ratee_id, score, comment)
            models.add_notification(ratee_id, f"{user.full_name} left you a {score}-star rating.",
                                     link=f"/profile/{ratee_id}")
            flash("Thanks for your feedback!", "success")
            return redirect(url_for("match.exchange_detail", exchange_id=exchange_id))

    return render_template("rate_exchange.html", exchange_id=exchange_id, ratee=ratee)
