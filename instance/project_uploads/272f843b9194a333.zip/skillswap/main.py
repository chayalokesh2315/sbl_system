from flask import Blueprint, render_template

import models
from authutils import login_required, get_current_user

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    return render_template("index.html")


@main_bp.route("/dashboard")
@login_required
def dashboard():
    user = get_current_user()
    offered = models.get_employee_skills(user.id, kind="offer")
    wanted = models.get_employee_skills(user.id, kind="want")
    active_exchanges = [e for e in models.list_exchanges_for(user.id) if e["status"] == "accepted"]
    upcoming_sessions = models.list_upcoming_sessions_for(user.id)
    completed = models.count_completed_sessions(user.id)
    badges = models.badges_for(user.id)
    matches = models.find_matches(user.id)[:3]
    unread = models.count_unread_notifications(user.id)

    return render_template(
        "dashboard.html", offered=offered, wanted=wanted,
        active_exchanges=active_exchanges, upcoming_sessions=upcoming_sessions,
        completed=completed, badges=badges, matches=matches, unread=unread,
    )


@main_bp.route("/leaderboard")
def leaderboard():
    top = models.leaderboard(10)
    return render_template("leaderboard.html", top=top)
