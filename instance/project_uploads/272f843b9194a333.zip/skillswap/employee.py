from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import login_required, get_current_user

employee_bp = Blueprint("employee", __name__, url_prefix="/profile")


@employee_bp.route("/<int:employee_id>")
def view(employee_id):
    emp = models.get_employee(employee_id)
    if not emp:
        flash("Employee not found.", "error")
        return redirect(url_for("main.dashboard"))
    offered = models.get_employee_skills(employee_id, kind="offer")
    wanted = models.get_employee_skills(employee_id, kind="want")
    badges = models.badges_for(employee_id)
    rating = models.average_rating(employee_id)
    reviews = models.get_ratings_for(employee_id)
    dept = models.department_name(emp._row["department_id"])
    return render_template("profile.html", emp=emp, offered=offered, wanted=wanted,
                            badges=badges, rating=rating, reviews=reviews, dept=dept)


@employee_bp.route("/edit", methods=["GET", "POST"])
@login_required
def edit():
    user = get_current_user()
    departments = models.list_departments()
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        department_id = request.form.get("department_id") or None
        designation = request.form.get("designation", "").strip()
        experience_level = request.form.get("experience_level", "beginner")
        bio = request.form.get("bio", "").strip()
        models.update_profile(user.id, full_name, department_id, designation, experience_level, bio)
        flash("Profile updated.", "success")
        return redirect(url_for("employee.view", employee_id=user.id))
    return render_template("profile_edit.html", user=user, departments=departments)


@employee_bp.route("/skills", methods=["GET", "POST"])
@login_required
def edit_skills():
    user = get_current_user()
    if request.method == "POST":
        skill_name = request.form.get("skill_name", "").strip().lower()
        category = request.form.get("category", "general").strip().lower()
        kind = request.form.get("kind")
        level = request.form.get("level", "beginner")

        if not skill_name or kind not in ("offer", "want"):
            flash("Please provide a valid skill and type.", "error")
        else:
            skill = models.get_skill_by_name(skill_name) or models.create_skill(skill_name, category)
            models.add_employee_skill(user.id, skill["id"], kind, level)
            flash(f'Added "{skill_name}" to your {"offered" if kind == "offer" else "wanted"} skills.', "success")
        return redirect(url_for("employee.edit_skills"))

    offered = models.get_employee_skills(user.id, kind="offer")
    wanted = models.get_employee_skills(user.id, kind="want")
    all_skills = models.list_skills()
    return render_template("skills_edit.html", offered=offered, wanted=wanted, all_skills=all_skills)


@employee_bp.route("/skills/<int:entry_id>/remove", methods=["POST"])
@login_required
def remove_skill(entry_id):
    user = get_current_user()
    models.remove_employee_skill(entry_id, user.id)
    flash("Skill removed.", "info")
    return redirect(url_for("employee.edit_skills"))
