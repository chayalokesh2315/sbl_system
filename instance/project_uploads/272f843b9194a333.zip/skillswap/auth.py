from flask import Blueprint, render_template, redirect, url_for, flash, request, session

import models
from authutils import get_current_user

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if get_current_user().is_authenticated:
        return redirect(url_for("main.dashboard"))

    departments = models.list_departments()

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        full_name = request.form.get("full_name", "").strip()
        department_id = request.form.get("department_id") or None
        designation = request.form.get("designation", "").strip()
        experience_level = request.form.get("experience_level", "beginner")

        if not username or not email or not password or not full_name:
            flash("Please fill in all required fields.", "error")
            return render_template("register.html", departments=departments)
        if password != confirm:
            flash("Passwords do not match.", "error")
            return render_template("register.html", departments=departments)
        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            return render_template("register.html", departments=departments)
        if models.employee_exists(username, email):
            flash("Username or email already registered.", "error")
            return render_template("register.html", departments=departments)

        user = models.create_employee(
            username, email, password, full_name,
            department_id=department_id, designation=designation,
            experience_level=experience_level,
        )
        session["employee_id"] = user.id
        flash("Welcome to SkillSwap!", "success")
        return redirect(url_for("employee.edit_skills"))

    return render_template("register.html", departments=departments)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if get_current_user().is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")

        user = models.get_employee_by_identifier(identifier)
        if user and models.check_password(user, password):
            if user._row["is_blocked"]:
                flash("This account has been blocked by an admin.", "error")
                return render_template("login.html")
            session["employee_id"] = user.id
            flash(f"Welcome back, {user.full_name}!", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("main.dashboard"))

        flash("Invalid username/email or password.", "error")

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.pop("employee_id", None)
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    """
    Simplified reset flow (no email service configured): verify identity via
    username + email match, then allow setting a new password directly.
    """
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        new_password = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")

        user = models.get_employee_by_identifier(username)
        if not user or user.email.lower() != email:
            flash("No account matches that username and email combination.", "error")
        elif new_password != confirm:
            flash("Passwords do not match.", "error")
        elif len(new_password) < 6:
            flash("Password must be at least 6 characters.", "error")
        else:
            models.set_password(user.id, new_password)
            flash("Password updated — you can log in now.", "success")
            return redirect(url_for("auth.login"))

    return render_template("forgot_password.html")
