from flask import Blueprint, render_template, request, redirect, url_for, flash

import models
from authutils import login_required, get_current_user

resources_bp = Blueprint("resources", __name__, url_prefix="/resources")


@resources_bp.route("/", methods=["GET"])
@login_required
def list_all():
    skill_id = request.args.get("skill_id", type=int)
    resources = models.list_resources(skill_id=skill_id)
    skills = models.list_skills()
    return render_template("resources.html", resources=resources, skills=skills, skill_id=skill_id)


@resources_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    user = get_current_user()
    skills = models.list_skills()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        url_ = request.form.get("url", "").strip()
        skill_id = request.form.get("skill_id") or None

        if not title or not url_:
            flash("A title and a link are required.", "error")
        else:
            models.add_resource(user.id, title, description, url_, skill_id=skill_id)
            flash("Resource shared.", "success")
            return redirect(url_for("resources.list_all"))

    return render_template("resource_form.html", skills=skills)


@resources_bp.route("/<int:resource_id>/delete", methods=["POST"])
@login_required
def delete(resource_id):
    models.delete_resource(resource_id)
    flash("Resource removed.", "info")
    return redirect(url_for("resources.list_all"))
