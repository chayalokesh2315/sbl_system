# SkillSwap — Employee Skill Exchange Platform

A peer-to-peer platform where employees list skills they can teach and
skills they want to learn, get matched with compatible colleagues, run
structured skill exchanges (request → accept → schedule sessions →
complete → rate), and earn points/badges along the way.

## Modules implemented (all core + most advanced modules from the spec)

| # | Module | Status |
|---|--------|--------|
| 1 | Employee Module (profile, dept, designation, skills, experience) | ✅ |
| 2 | Authentication (signup/login/logout, role-based access, password reset) | ✅ |
| 3 | Skill Management (add/edit/delete, categories, levels) | ✅ |
| 4 | Skill Matching (compatibility score, mutual-match detection) | ✅ |
| 5 | Skill Exchange (request/accept/reject/complete) | ✅ |
| 6 | Session Management (schedule/reschedule/cancel, online/offline) | ✅ |
| 7 | Communication (chat) | ⏳ Not built — see roadmap |
| 8 | Rating & Feedback | ✅ |
| 9 | Gamification (points, badges, leaderboard) | ✅ |
| 10 | Learning Resources (share links/notes) | ✅ |
| 11 | Dashboard | ✅ |
| 12 | Notifications (in-app) | ✅ |
| 13 | Admin (employees, skills, departments, exchanges, block/unblock) | ✅ |
| 14 | Reports & Analytics (popular skills, active employees, dept participation) | ✅ |

The only module intentionally left out is **live chat** — real-time
messaging needs either WebSockets/polling infrastructure or a third-party
service, which is a distinct build from the request/response pattern
everything else here uses. See the roadmap below for how to add it.

## Running it

```bash
cd skillswap
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python3 app.py
```

Open **http://localhost:5001** (5001, not 5000, so it can run alongside
other Flask projects). The database and starter data (7 departments, 12
common skills) are created automatically on first run.

To make an account an admin:

```bash
python3 -c "
from db import get_db
conn = get_db()
conn.execute(\"UPDATE employees SET role='admin' WHERE username='YOUR_USERNAME'\")
conn.commit()
"
```

## How matching works

For employee E, the matcher looks at:
- Everyone who **offers** a skill E **wants** → E can learn from them
- Everyone who **wants** a skill E **offers** → E can teach them

A candidate who appears in both lists is a **mutual match** (the classic
"A teaches Python/wants UI-UX, B teaches UI-UX/wants Python" case from the
spec) and is ranked highest, with a compatibility score = total number of
overlapping skill pairs in either direction. This is deliberately a simple,
explainable scoring rule rather than an ML model — appropriate for a
resume/academic project and easy to defend in a viva.

## Why plain sqlite3 instead of an ORM?

Same reasoning as any Flask+SQLite student project: zero extra
dependencies (`pip install flask` is the whole setup), and everything is
plain, readable SQL in `models.py` if you need to explain or modify it.
If you'd prefer Flask-SQLAlchemy/Flask-Login for a more "textbook"
architecture, that's a straightforward swap — ask and I'll convert it.

## What was tested before handoff

Every module was exercised end-to-end with Flask's test client (not just
written and assumed to work):

- Register two employees, each with complementary offered/wanted skills
- Confirmed the matcher correctly flags them as a **mutual match**
- Sent an exchange request → accepted it → scheduled a session →
  completed it → confirmed **points were awarded to both participants**
- Marked the exchange completed → rated the partner → confirmed rating
  points were added
- Verified both employees appear correctly on the **leaderboard**
- Shared a learning resource and confirmed it's listed
- Confirmed notifications are generated for match requests
- Verified a non-admin gets a **403** on `/admin/*`
- Promoted a user to admin and tested: dashboard, add skill, add
  department, exchange monitor
- **Blocked an employee as admin and confirmed they're rejected at
  login** — this edge case is easy to miss and was explicitly checked
- Tested the simplified forgot-password flow (reset → login with new
  password)
- Tested profile editing

## Roadmap: adding real-time chat (Module 7)

1. Add a `messages` table (`exchange_id`, `sender_id`, `body`,
   `created_at`) — the schema pattern already exists in `db.py`
2. Simplest version: a `/exchanges/<id>/messages` POST + GET route pair,
   polling every few seconds from the front end — no new dependencies
3. For real-time delivery: add `Flask-SocketIO` (needs `pip install`, so
   requires internet access to set up) and emit on new message
4. Tie into the existing notification system — a new message should call
   `models.add_notification()` the same way exchange events do

## Other future improvements

- File uploads for resources (currently link-only) — would need a
  configured upload folder and file-type validation
- Email delivery for the password reset flow, instead of the current
  simplified username+email verification
- Weighted matching (factor in skill *level* compatibility, not just
  overlap — e.g. prioritize an advanced teacher for a beginner learner)
