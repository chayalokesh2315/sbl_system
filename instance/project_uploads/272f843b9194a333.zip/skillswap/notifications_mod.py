from flask import Blueprint, render_template, redirect, url_for

import models
from authutils import login_required, get_current_user

notifications_bp = Blueprint("notifications", __name__, url_prefix="/notifications")


@notifications_bp.route("/")
@login_required
def list_all():
    user = get_current_user()
    items = models.list_notifications(user.id)
    models.mark_notifications_read(user.id)
    return render_template("notifications.html", items=items)
