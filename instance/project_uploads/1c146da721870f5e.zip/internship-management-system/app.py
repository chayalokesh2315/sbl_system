import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash, check_password_hash

# ----------------------------------------------------------------------------
# App / Config
# ----------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'instance', 'ims.db')

app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-this-secret-key-in-production'


# ----------------------------------------------------------------------------
# Database helpers
# ----------------------------------------------------------------------------
def get_db():
    if 'db' not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS internship (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    company TEXT NOT NULL,
    location TEXT NOT NULL,
    duration TEXT NOT NULL,
    stipend TEXT,
    description TEXT NOT NULL,
    skills_required TEXT,
    posted_on TEXT NOT NULL,
    deadline TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS application (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES user(id) ON DELETE CASCADE,
    internship_id INTEGER NOT NULL REFERENCES internship(id) ON DELETE CASCADE,
    cover_note TEXT,
    status TEXT NOT NULL DEFAULT 'Pending',
    applied_on TEXT NOT NULL,
    UNIQUE(student_id, internship_id)
);
"""


def init_database():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)

    cur = conn.execute('SELECT id FROM user WHERE email = ?', ('admin@ims.local',))
    if cur.fetchone() is None:
        conn.execute(
            'INSERT INTO user (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)',
            ('Admin', 'admin@ims.local', generate_password_hash('admin123'), 'admin',
             datetime.utcnow().isoformat())
        )

    cur = conn.execute('SELECT COUNT(*) AS c FROM internship')
    if cur.fetchone()['c'] == 0:
        now = datetime.utcnow().isoformat()
        conn.executemany(
            """INSERT INTO internship
               (title, company, location, duration, stipend, description, skills_required, posted_on, deadline, is_active)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
            [
                ('Full-Stack Web Development Intern', 'TechNova Solutions', 'Bangalore (Remote)',
                 '3 months', '8000/month',
                 'Work on real client projects using Flask, React and PostgreSQL. '
                 'Mentored by senior engineers with weekly code reviews.',
                 'Python, Flask, JavaScript, HTML/CSS', now, None),
                ('Data Analytics Intern', 'Insight Analytics', 'Bangalore',
                 '2 months', 'Unpaid + Certificate',
                 'Analyze business datasets, build dashboards and present insights to '
                 'stakeholders using Python and SQL.',
                 'Python, SQL, Excel, Power BI', now, None),
            ]
        )

    conn.commit()
    conn.close()
    print(f'Database initialized at {DB_PATH}. Admin login -> admin@ims.local / admin123')


@app.cli.command('init-db')
def init_db_command():
    """Create tables and seed a default admin account + sample data."""
    init_database()


# ----------------------------------------------------------------------------
# Helpers / decorators
# ----------------------------------------------------------------------------
def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to continue.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapped


def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return wrapped


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return get_db().execute('SELECT * FROM user WHERE id = ?', (uid,)).fetchone()


@app.context_processor
def inject_user():
    return dict(current_user=current_user())


@app.template_filter('fmtdate')
def fmtdate(value, fmt='%d %b %Y'):
    if not value:
        return ''
    try:
        dt = datetime.fromisoformat(value)
        return dt.strftime(fmt)
    except (ValueError, TypeError):
        return value


# ----------------------------------------------------------------------------
# Public routes
# ----------------------------------------------------------------------------
@app.route('/')
def index():
    db = get_db()
    internships = db.execute(
        'SELECT * FROM internship WHERE is_active = 1 ORDER BY posted_on DESC'
    ).fetchall()
    return render_template('index.html', internships=internships)


@app.route('/internship/<int:internship_id>')
def internship_detail(internship_id):
    db = get_db()
    internship = db.execute('SELECT * FROM internship WHERE id = ?', (internship_id,)).fetchone()
    if internship is None:
        flash('Internship not found.', 'danger')
        return redirect(url_for('index'))

    already_applied = False
    if session.get('user_id'):
        existing = db.execute(
            'SELECT id FROM application WHERE student_id = ? AND internship_id = ?',
            (session['user_id'], internship_id)
        ).fetchone()
        already_applied = existing is not None

    return render_template('internship_detail.html', internship=internship, already_applied=already_applied)


# ----------------------------------------------------------------------------
# Auth routes
# ----------------------------------------------------------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not name or not email or not password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))

        db = get_db()
        existing = db.execute('SELECT id FROM user WHERE email = ?', (email,)).fetchone()
        if existing:
            flash('An account with this email already exists.', 'danger')
            return redirect(url_for('register'))

        db.execute(
            'INSERT INTO user (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)',
            (name, email, generate_password_hash(password), 'student', datetime.utcnow().isoformat())
        )
        db.commit()

        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        db = get_db()
        user = db.execute('SELECT * FROM user WHERE email = ?', (email,)).fetchone()

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['name'] = user['name']
            flash(f"Welcome back, {user['name']}!", 'success')
            return redirect(url_for('dashboard'))

        flash('Invalid email or password.', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


# ----------------------------------------------------------------------------
# Student routes
# ----------------------------------------------------------------------------
@app.route('/dashboard')
@login_required
def dashboard():
    if session.get('role') == 'admin':
        return redirect(url_for('admin_dashboard'))

    db = get_db()
    applications = db.execute(
        """SELECT application.*, internship.title AS i_title, internship.company AS i_company,
                  internship.id AS i_id
           FROM application
           JOIN internship ON internship.id = application.internship_id
           WHERE application.student_id = ?
           ORDER BY application.applied_on DESC""",
        (session['user_id'],)
    ).fetchall()
    return render_template('student_dashboard.html', applications=applications)


@app.route('/apply/<int:internship_id>', methods=['GET', 'POST'])
@login_required
def apply(internship_id):
    if session.get('role') == 'admin':
        flash('Admins cannot apply to internships.', 'warning')
        return redirect(url_for('index'))

    db = get_db()
    internship = db.execute('SELECT * FROM internship WHERE id = ?', (internship_id,)).fetchone()
    if internship is None:
        flash('Internship not found.', 'danger')
        return redirect(url_for('index'))

    existing = db.execute(
        'SELECT id FROM application WHERE student_id = ? AND internship_id = ?',
        (session['user_id'], internship_id)
    ).fetchone()
    if existing:
        flash('You have already applied to this internship.', 'info')
        return redirect(url_for('internship_detail', internship_id=internship_id))

    if request.method == 'POST':
        cover_note = request.form.get('cover_note', '').strip()
        db.execute(
            'INSERT INTO application (student_id, internship_id, cover_note, status, applied_on) '
            'VALUES (?, ?, ?, ?, ?)',
            (session['user_id'], internship_id, cover_note, 'Pending', datetime.utcnow().isoformat())
        )
        db.commit()
        flash('Application submitted successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('apply.html', internship=internship)


@app.route('/application/<int:application_id>/withdraw', methods=['POST'])
@login_required
def withdraw_application(application_id):
    db = get_db()
    application = db.execute('SELECT * FROM application WHERE id = ?', (application_id,)).fetchone()
    if application is None or application['student_id'] != session['user_id']:
        flash('You cannot withdraw this application.', 'danger')
        return redirect(url_for('dashboard'))

    db.execute('DELETE FROM application WHERE id = ?', (application_id,))
    db.commit()
    flash('Application withdrawn.', 'info')
    return redirect(url_for('dashboard'))


# ----------------------------------------------------------------------------
# Admin routes
# ----------------------------------------------------------------------------
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    db = get_db()
    total_internships = db.execute('SELECT COUNT(*) AS c FROM internship').fetchone()['c']
    total_applications = db.execute('SELECT COUNT(*) AS c FROM application').fetchone()['c']
    total_students = db.execute("SELECT COUNT(*) AS c FROM user WHERE role = 'student'").fetchone()['c']
    pending = db.execute("SELECT COUNT(*) AS c FROM application WHERE status = 'Pending'").fetchone()['c']

    internships = db.execute(
        """SELECT internship.*,
                  (SELECT COUNT(*) FROM application WHERE application.internship_id = internship.id) AS app_count
           FROM internship
           ORDER BY posted_on DESC"""
    ).fetchall()

    return render_template(
        'admin_dashboard.html',
        internships=internships,
        total_internships=total_internships,
        total_applications=total_applications,
        total_students=total_students,
        pending=pending,
    )


@app.route('/admin/internship/new', methods=['GET', 'POST'])
@login_required
@admin_required
def new_internship():
    if request.method == 'POST':
        db = get_db()
        db.execute(
            """INSERT INTO internship
               (title, company, location, duration, stipend, description, skills_required, posted_on, deadline, is_active)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)""",
            (
                request.form.get('title', '').strip(),
                request.form.get('company', '').strip(),
                request.form.get('location', '').strip(),
                request.form.get('duration', '').strip(),
                request.form.get('stipend', '').strip(),
                request.form.get('description', '').strip(),
                request.form.get('skills_required', '').strip(),
                datetime.utcnow().isoformat(),
                request.form.get('deadline') or None,
            )
        )
        db.commit()
        flash('Internship posted successfully.', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('internship_form.html', internship=None)


@app.route('/admin/internship/<int:internship_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_internship(internship_id):
    db = get_db()
    internship = db.execute('SELECT * FROM internship WHERE id = ?', (internship_id,)).fetchone()
    if internship is None:
        flash('Internship not found.', 'danger')
        return redirect(url_for('admin_dashboard'))

    if request.method == 'POST':
        is_active = 1 if 'is_active' in request.form else 0
        db.execute(
            """UPDATE internship SET title=?, company=?, location=?, duration=?, stipend=?,
               description=?, skills_required=?, deadline=?, is_active=? WHERE id=?""",
            (
                request.form.get('title', '').strip(),
                request.form.get('company', '').strip(),
                request.form.get('location', '').strip(),
                request.form.get('duration', '').strip(),
                request.form.get('stipend', '').strip(),
                request.form.get('description', '').strip(),
                request.form.get('skills_required', '').strip(),
                request.form.get('deadline') or None,
                is_active,
                internship_id,
            )
        )
        db.commit()
        flash('Internship updated.', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('internship_form.html', internship=internship)


@app.route('/admin/internship/<int:internship_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_internship(internship_id):
    db = get_db()
    db.execute('DELETE FROM internship WHERE id = ?', (internship_id,))
    db.commit()
    flash('Internship deleted.', 'info')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin/internship/<int:internship_id>/applications')
@login_required
@admin_required
def view_applications(internship_id):
    db = get_db()
    internship = db.execute('SELECT * FROM internship WHERE id = ?', (internship_id,)).fetchone()
    if internship is None:
        flash('Internship not found.', 'danger')
        return redirect(url_for('admin_dashboard'))

    applications = db.execute(
        """SELECT application.*, user.name AS student_name, user.email AS student_email
           FROM application
           JOIN user ON user.id = application.student_id
           WHERE application.internship_id = ?
           ORDER BY application.applied_on DESC""",
        (internship_id,)
    ).fetchall()

    return render_template('applications_list.html', internship=internship, applications=applications)


@app.route('/admin/application/<int:application_id>/status', methods=['POST'])
@login_required
@admin_required
def update_application_status(application_id):
    db = get_db()
    application = db.execute('SELECT * FROM application WHERE id = ?', (application_id,)).fetchone()
    if application is None:
        flash('Application not found.', 'danger')
        return redirect(url_for('admin_dashboard'))

    new_status = request.form.get('status')
    if new_status in ('Pending', 'Accepted', 'Rejected'):
        db.execute('UPDATE application SET status = ? WHERE id = ?', (new_status, application_id))
        db.commit()
        flash('Application status updated.', 'success')

    return redirect(url_for('view_applications', internship_id=application['internship_id']))


# ----------------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------------
if __name__ == '__main__':
    if not os.path.exists(DB_PATH):
        init_database()
    app.run(debug=True)
