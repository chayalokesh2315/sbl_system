# Internship Management System

A Flask-based web application for managing internship postings and student applications.

## Tech Stack
Python + Flask + SQLite (built-in `sqlite3`, no extra ORM dependency) + HTML/CSS/JS

## Features

**Students**
- Register and log in
- Browse active internship postings
- View full internship details
- Apply with an optional cover note
- Track application status (Pending / Accepted / Rejected) on a personal dashboard
- Withdraw a pending application

**Admin**
- Secure admin login
- Dashboard with stats (total internships, applications, students, pending reviews)
- Post, edit, activate/deactivate, and delete internships
- View all applicants for each internship
- Accept or reject applications

## Project Structure
```
internship-management-system/
├── app.py                     # Flask app, models, and routes
├── requirements.txt
├── instance/
│   └── ims.db                 # SQLite database (auto-created)
├── static/
│   ├── css/style.css
│   └── js/script.js
└── templates/
    ├── base.html
    ├── index.html
    ├── internship_detail.html
    ├── login.html
    ├── register.html
    ├── student_dashboard.html
    ├── apply.html
    ├── admin_dashboard.html
    ├── internship_form.html
    └── applications_list.html
```

## Setup & Run

1. Create a virtual environment (recommended):
   ```
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Initialize the database (creates tables + a default admin account + 2 sample internships):
   ```
   flask --app app init-db
   ```

4. Run the app:
   ```
   python app.py
   ```

5. Open your browser at `http://127.0.0.1:5000`

## Default Admin Login
```
Email:    admin@ims.local
Password: admin123
```

## Notes
- Change `app.config['SECRET_KEY']` before deploying anywhere public.
- The SQLite database file is created inside `instance/` automatically.
